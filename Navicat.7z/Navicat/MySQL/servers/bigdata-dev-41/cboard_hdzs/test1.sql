        SELECT count(1) FROM dashboard_dataset WHERE dataset_id = 
564 and ('2769258110d240ab98263bad3140ca82' = '1' OR user_id = '2769258110d240ab98263bad3140ca82' OR dataset_id IN
 (SELECT res_id FROM dashboard_user_role ur LEFT JOIN dashboard_role_res rr ON ur.role_id = rr.role_id 
WHERE ur.user_id = '2769258110d240ab98263bad3140ca82' AND rr.res_type = 'dataset' AND rr.permission LIKE '%'))




