SELECT
	id,
	region,
	community_id,
	community_name,
	stat_time,
	create_time,
	session_id,
	replay_order,
	CONCAT(
		floor(replay_time / 1000 / 3600),
		"小时",
		floor(replay_time / 1000 % 3600 / 60),
		"分钟",
		floor(replay_time / 1000 % 3600 % 60),
		"秒"
	),
	from_unixtime(
		start_time / 1000,
		'%Y-%m-%d %H:%i:%s'
	),
	from_unixtime(
		end_time / 1000,
		'%Y-%m-%d %H:%i:%s'
	)
FROM
	`chat_compute_detail`
WHERE
	stat_time = '2020-05-05';





