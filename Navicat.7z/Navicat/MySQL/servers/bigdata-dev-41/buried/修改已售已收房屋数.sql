SELECT
	hc.`项目名称`,
	hc.`住宅-已售已收户数`,
	hc.`商业-已售已收户数`,
	hc.`住宅-已售已收户数` + hc.`商业-已售已收户数`
FROM
	buried.`house_count` hc;





SELECT
	hhc.项目名称,
	hhc.已售已收户数
FROM
	buried.henan_house_count hhc;



SELECT
	hcq.project_name,
	hcq.total_house_number
FROM
	dashboard_job.hdsc_cboard_query hcq
where hcq.project_name='宜昌恒大山水城'
;




update dashboard_job.hdsc_cboard_query hcq
left join buried.`house_count` hc on hcq.project_name=hc.`项目名称`
set hcq.total_house_number=hc.`住宅-已售已收户数` + hc.`商业-已售已收户数`;



select * from buried.henan_house_count hhc
LEFT JOIN  dashboard_job.hdsc_cboard_query hcq on hcq.project_name=hhc.项目名称

where hcq.project_name is null;

update dashboard_job.hdsc_cboard_query hcq
join buried.henan_house_count hhc on hcq.project_name=hhc.项目名称
set hcq.total_house_number=hhc.已售已收户数;
