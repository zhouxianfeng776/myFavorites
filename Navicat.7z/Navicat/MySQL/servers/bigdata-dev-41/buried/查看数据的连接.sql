show full processlist;

KILL 41515;
