SELECT
	region 地区公司,
	community_name 小区名称,
	session_id 会话的标识,
	stat_time 统计时间,
	send_time 会话发送时间,
	message 消息内容,
	user_name 发送消息人姓名,
	CASE user_type
WHEN 0 THEN
	'业主'
WHEN 1 THEN
	'管家'
END 人员类型,
 to_name 接收人姓名,
 CASE is_replay
WHEN 0 THEN
	'是'
WHEN 1 THEN
	'不是'
END 是否未回复,
 CASE is_first_no_replay
WHEN 0 THEN
	'不是'
WHEN 1 THEN
	'是'
END 是否首次未回复
FROM
	buried.chat_detail
WHERE
	stat_time = '2020-06-14'
	and is_first_no_replay=1
;