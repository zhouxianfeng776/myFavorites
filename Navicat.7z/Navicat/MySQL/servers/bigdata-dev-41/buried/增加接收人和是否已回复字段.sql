ALTER TABLE buried.`chat_detail`
ADD COLUMN `to_name`  varchar(128) NULL DEFAULT NULL COMMENT '接收消息人' AFTER `session_id`;

ALTER TABLE buried.`chat_detail`
ADD COLUMN `is_replay`  tinyint(1) UNSIGNED NULL DEFAULT NULL COMMENT '是已回复？1：是，0未' AFTER `to_name`;