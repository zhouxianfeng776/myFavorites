SELECT
	nation 全国,
	message_quantity 消息数量,
	owner_send_nums 发送消息的用户个数,
	total_house_number 已售已收户数,
	active_sum 活跃人数,
	use_rate 使用率,
	recovery_rate 回复率,
	CONCAT(
		floor(
			first_response_time_avg / 1000 / 3600
		),
		":",
		floor(
			first_response_time_avg / 1000 % 3600 / 60
		),
		":",
		floor(
			first_response_time_avg / 1000 % 3600 % 60
		)
	) 首次回复的平均响应时长,
	CONCAT(
		floor(
			first_response_time_max / 1000 / 3600
		),
		":",
		floor(
			first_response_time_max / 1000 % 3600 / 60
		),
		":",
		floor(
			first_response_time_max / 1000 % 3600 % 60
		)
	) 首次回复的最大响应时长,
	CONCAT(
		floor(
			response_time_avg / 1000 / 3600
		),
		":",
		floor(
			response_time_avg / 1000 % 3600 / 60
		),
		":",
		floor(
			response_time_avg / 1000 % 3600 % 60
		)
	) 回复的平均响应时长,
	CONCAT(
		floor(
			response_time_max / 1000 / 3600
		),
		":",
		floor(
			response_time_max / 1000 % 3600 / 60
		),
		":",
		floor(
			response_time_max / 1000 % 3600 % 60
		)
	) 回复的最大响应时长
FROM
	buried.online_housekeeper_stat_nation
WHERE
	stat_time = '2020-06-11';

SELECT
	region 地区公司,
	message_quantity 消息数量,
	owner_send_nums 发送消息的用户个数,
	total_house_number 已售已收户数,
	active_sum 活跃人数,
	use_rate 使用率,
	recovery_rate 回复率,
	CONCAT(
		floor(
			first_response_time_avg / 1000 / 3600
		),
		":",
		floor(
			first_response_time_avg / 1000 % 3600 / 60
		),
		":",
		floor(
			first_response_time_avg / 1000 % 3600 % 60
		)
	) 首次回复的平均响应时长,
	CONCAT(
		floor(
			first_response_time_max / 1000 / 3600
		),
		":",
		floor(
			first_response_time_max / 1000 % 3600 / 60
		),
		":",
		floor(
			first_response_time_max / 1000 % 3600 % 60
		)
	) 首次回复的最大响应时长,
	CONCAT(
		floor(
			response_time_avg / 1000 / 3600
		),
		":",
		floor(
			response_time_avg / 1000 % 3600 / 60
		),
		":",
		floor(
			response_time_avg / 1000 % 3600 % 60
		)
	) 回复的平均响应时长,
	CONCAT(
		floor(
			response_time_max / 1000 / 3600
		),
		":",
		floor(
			response_time_max / 1000 % 3600 / 60
		),
		":",
		floor(
			response_time_max / 1000 % 3600 % 60
		)
	) 回复的最大响应时长
FROM
	buried.online_housekeeper_stat_region
WHERE
	stat_time = '2020-06-11'
UNION
	SELECT
		hcq.region_company 地区公司,
		0 消息数量,
		0 发送消息的用户个数,
		sum(
			IFNULL(hcq.total_house_number, 0)
		) 已售已收户数,
		sum(IFNULL(aps.active_sum, 0)) 已售已收户数,
		'0.00%' 使用率,
		'0.00%' 回复率,
		'0:0:0' 首次回复的平均响应时长,
		'0:0:0' 首次回复的最大响应时长,
		'0:0:0' 回复的平均响应时长,
		'0:0:0' 回复的最大响应时长
	FROM
		dashboard_job.hdsc_cboard_query hcq
	LEFT JOIN buried.online_housekeeper_stat_region ohsr ON hcq.region_company = ohsr.region
	AND ohsr.stat_time = '2020-06-11'
	LEFT JOIN buried.actives_project_statistics aps ON hcq.court_uuid = aps.court_id
	AND initialDate = '2020-06-11'
	AND OFFSET = 0
	WHERE
		ohsr.id IS NULL
	GROUP BY
		hcq.region_company;

SELECT
	region 地区公司,
	project 小区名称,
	message_quantity 消息数量,
	owner_send_nums 发送消息的用户个数,
	total_house_number 已售已收户数,
	active_sum 活跃人数,
	use_rate 使用率,
	recovery_rate 回复率,
	CONCAT(
		floor(
			first_response_time_avg / 1000 / 3600
		),
		":",
		floor(
			first_response_time_avg / 1000 % 3600 / 60
		),
		":",
		floor(
			first_response_time_avg / 1000 % 3600 % 60
		)
	) 首次回复的平均响应时长,
	CONCAT(
		floor(
			first_response_time_max / 1000 / 3600
		),
		":",
		floor(
			first_response_time_max / 1000 % 3600 / 60
		),
		":",
		floor(
			first_response_time_max / 1000 % 3600 % 60
		)
	) 首次回复的最大响应时长,
	CONCAT(
		floor(
			response_time_avg / 1000 / 3600
		),
		":",
		floor(
			response_time_avg / 1000 % 3600 / 60
		),
		":",
		floor(
			response_time_avg / 1000 % 3600 % 60
		)
	) 回复的平均响应时长,
	CONCAT(
		floor(
			response_time_max / 1000 / 3600
		),
		":",
		floor(
			response_time_max / 1000 % 3600 / 60
		),
		":",
		floor(
			response_time_max / 1000 % 3600 % 60
		)
	) 回复的最大响应时长
FROM
	buried.online_housekeeper_stat_project
WHERE
	stat_time = '2020-06-11'
UNION
	SELECT
		hcq.region_company 地区公司,
		hcq.project_name 小区名称,
		0 消息数量,
		0 发送消息的用户个数,
		IFNULL(hcq.total_house_number, 0) 已售已收户数,
		IFNULL(aps.active_sum, 0) 已售已收户数,
		'0.0000%' 使用率,
		'0.00%' 回复率,
		'0:0:0' 首次回复的平均响应时长,
		'0:0:0' 首次回复的最大响应时长,
		'0:0:0' 回复的平均响应时长,
		'0:0:0' 回复的最大响应时长
	FROM
		dashboard_job.hdsc_cboard_query hcq
	LEFT JOIN buried.online_housekeeper_stat_project ohsp ON hcq.project_name = ohsp.project
	AND ohsp.stat_time = '2020-06-11'
	LEFT JOIN dashboard_job.exclude_project ep ON hcq.erp_precinct_short_name = ep.project_name
	LEFT JOIN buried.actives_project_statistics aps ON hcq.court_uuid = aps.court_id
	AND initialDate = '2020-06-11'
	AND OFFSET = 0
	WHERE
		ep.project_name IS NULL
	AND ohsp.id IS NULL
	AND hcq.court_uuid IS NOT NULL;

SELECT
	region 地区公司,
	community_name 小区名称,
	session_id 会话的标识,
	stat_time 统计时间,
	send_time 会话发送时间,
	message 消息内容,
	user_name 发送消息人姓名,
	CASE user_type
WHEN 0 THEN
	'业主'
WHEN 1 THEN
	'管家'
END 人员类型,
 to_name 接收人姓名,
 CASE is_replay
WHEN 0 THEN
	'是'
WHEN 1 THEN
	'不是'
END 是否未回复,
 CASE is_first_no_replay
WHEN 0 THEN
	'不是'
WHEN 1 THEN
	'是'
END 是否首次未回复
FROM
	buried.chat_detail
WHERE
	stat_time = '2020-06-11';

SELECT
	region 地区地区公司,
	community_name 小区名称,
	session_id 会话的标识,
	stat_time 统计时间,
	replay_order 第？次回复的顺序,
	CONCAT(
		floor(replay_time / 1000 / 3600),
		":",
		floor(replay_time / 1000 % 3600 / 60),
		":",
		floor(replay_time / 1000 % 3600 % 60)
	) 当前回复次数的时间间隔,
	from_unixtime(
		start_time / 1000,
		'%Y-%m-%d %H:%i:%s'
	) 会话开始时间,
	from_unixtime(
		end_time / 1000,
		'%Y-%m-%d %H:%i:%s'
	) 会话结束时间
FROM
	buried.chat_compute_detail
WHERE
	stat_time = '2020-06-11';

