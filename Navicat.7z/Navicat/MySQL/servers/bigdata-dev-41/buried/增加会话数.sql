ALTER TABLE `buried`.`online_housekeeper_stat_region`
ADD COLUMN `first_response_time_sum`  bigint UNSIGNED NULL DEFAULT 0 COMMENT '首次回复的响应时长的和' AFTER `use_rate`,
ADD COLUMN `first_session_num`  bigint UNSIGNED NULL DEFAULT 0 COMMENT '首次会话的数量' AFTER `first_response_time_sum`,
ADD COLUMN `response_time_sum`  bigint UNSIGNED NULL DEFAULT 0 COMMENT '回复时长的总和' AFTER `first_session_num`,
ADD COLUMN `session_num`  bigint UNSIGNED NULL DEFAULT 0 COMMENT '总的会话数量' AFTER `response_time_sum`,
ADD COLUMN `have_replay_owner`  int UNSIGNED NULL DEFAULT 0 COMMENT '有回复的业主数量' AFTER `session_num`,
ADD COLUMN `active_sum`  int UNSIGNED NULL DEFAULT 0 COMMENT '活跃人数' AFTER `have_replay_owner`;


ALTER TABLE `buried`.`online_housekeeper_stat_project`
ADD COLUMN `first_response_time_sum`  bigint UNSIGNED NULL DEFAULT 0 COMMENT '首次回复的响应时长的和' AFTER `use_rate`,
ADD COLUMN `first_session_num`  bigint UNSIGNED NULL DEFAULT 0 COMMENT '首次会话的数量' AFTER `first_response_time_sum`,
ADD COLUMN `response_time_sum`  bigint UNSIGNED NULL DEFAULT 0 COMMENT '回复时长的总和' AFTER `first_session_num`,
ADD COLUMN `session_num`  bigint UNSIGNED NULL DEFAULT 0 COMMENT '总的会话数量' AFTER `response_time_sum`,
ADD COLUMN `have_replay_owner`  int UNSIGNED NULL DEFAULT 0 COMMENT '有回复的业主数量' AFTER `session_num`,
ADD COLUMN `active_sum`  int UNSIGNED NULL DEFAULT 0 COMMENT '活跃人数' AFTER `have_replay_owner`;


ALTER TABLE `buried`.`online_housekeeper_stat_nation`
ADD COLUMN `first_response_time_sum`  bigint UNSIGNED NULL DEFAULT 0 COMMENT '首次回复的响应时长的和' AFTER `first_response_time_max`,
ADD COLUMN `first_session_num`  bigint UNSIGNED NULL DEFAULT 0 COMMENT '首次会话的数量' AFTER `first_response_time_sum`,
ADD COLUMN `response_time_sum`  bigint UNSIGNED NULL DEFAULT 0 COMMENT '回复时长的总和' AFTER `first_session_num`,
ADD COLUMN `session_num`  bigint UNSIGNED NULL DEFAULT 0 COMMENT '总的会话数量' AFTER `response_time_sum`,
ADD COLUMN `have_replay_owner`  int UNSIGNED NULL DEFAULT 0 COMMENT '有回复的业主数量' AFTER `session_num`,
ADD COLUMN `active_sum`  int UNSIGNED NULL DEFAULT 0 COMMENT '活跃人数' AFTER `have_replay_owner`;



CREATE TABLE IF NOT EXISTS `buried`.`actives_project_statistics`  (
  `id` varchar(56) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'UUID',
  `court_id` varchar(56) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '小区ID',
  `court_name` varchar(156) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '小区名称',
  `active_sum` int(10) NOT NULL COMMENT '活跃数量',
  `initialDate` varchar(56) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '用户活跃日期',
  `insertTime` varchar(56) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '插入日期 ',
  `offset` smallint(6) DEFAULT NULL COMMENT '计算日期偏移量',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_court_id_initDate_offset`(`court_id`, `initialDate`, `offset`) USING BTREE COMMENT '查询索引'
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;
