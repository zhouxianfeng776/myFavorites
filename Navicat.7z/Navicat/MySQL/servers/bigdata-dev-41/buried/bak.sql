

select * from dashboard_job.base_court;
select * from dashboard_job.test11;




select * from dashboard_job.test11 t1
left join dashboard_job.base_court bc on t1.project=bc.`name`

where bc.uuid is null;


select * from   dashboard_job.base_court bc
left join dashboard_job.test11 t1 on t1.project=bc.`name`

where t1.id is null;


select * from dashboard_job.test11 t1
where t1.project ='恒大新能源科技集团中国研究院深圳研发中心'

SELECT * FROM `hdsc_cboard_query`
where region_company='广东物业'

;

SELECT * FROM `hdsc_cboard_query`
where region_company like '%三角%'

;

create table hdsc_cboard_query_bak select * from hdsc_cboard_query;
select * from hdsc_cboard_query_bak



