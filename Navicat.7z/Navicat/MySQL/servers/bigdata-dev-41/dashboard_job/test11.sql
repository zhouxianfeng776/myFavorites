select * from hdsc_cboard_query hcq;

-- INSERT INTO table_name (列1, 列2,...) VALUES (值1, 值2,....)








insert into hdsc_cboard_query (court_uuid,erp_precinct_short_name,project_name,region_company,project_city)

select bc.uuid,t.project,t.project,t.company,t.city from test11 t
left join base_court bc on bc.name=t.project;


update hdsc_cboard_query hcq
left join user_count uc on hcq.court_uuid=uc.court_uuid
set hcq.user_count=uc.total

select *from hdsc_cboard_query  hcq
left join user_count uc on hcq.court_uuid=uc.court_uuid

where 


select * from user_count;










