


update hdsc_cboard_query set region_company='珠三角物业' where region_company='广东物业';
