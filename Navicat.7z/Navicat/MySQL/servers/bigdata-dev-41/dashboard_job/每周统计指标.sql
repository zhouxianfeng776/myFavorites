SELECT
	region 地区,
	sum(owner_send_nums) 使用人数
FROM
	buried.online_housekeeper_stat_region
WHERE
	stat_time >= '2020-06-11'
AND stat_time <= '2020-06-14'
GROUP BY
	region
ORDER BY
	使用人数 DESC;

SELECT
	region 地区,
	sum(message_quantity) 消息数量
FROM
	buried.online_housekeeper_stat_region
WHERE
	stat_time >= '2020-06-11'
AND stat_time <= '2020-06-14'
GROUP BY
	region
ORDER BY
	消息数量 DESC;

SELECT
	ohsr.region 地区,

IF (
	max(t.active_sum) = 0,
	'0.0000%',
	concat(
		ROUND(
			sum(ohsr.owner_send_nums) / max(t.active_sum) * 100,
			4
		),
		'%'
	)
) 使用率
FROM
	buried.online_housekeeper_stat_region ohsr
LEFT JOIN (
	SELECT
		hcq.region_company,
		SUM(IFNULL(aps.active_sum, 0)) active_sum
	FROM
		dashboard_job.hdsc_cboard_query hcq
	LEFT JOIN dashboard_job.exclude_project ep ON hcq.erp_precinct_short_name = ep.project_name
	LEFT JOIN buried.actives_project_statistics aps ON hcq.court_uuid = aps.court_id
	AND initialDate = '2020-06-14'
	AND OFFSET = - 6
	WHERE
		ep.project_name IS NULL
	GROUP BY
		hcq.region_company
) t ON t.region_company = ohsr.region
WHERE
	ohsr.stat_time >= '2020-06-11'
AND ohsr.stat_time <= '2020-06-14'
GROUP BY
	ohsr.region
ORDER BY
	sum(ohsr.owner_send_nums) / max(t.active_sum) DESC;

SELECT
	region 地区,

IF (
	SUM(owner_send_nums) = 0,
	'0.00%',
	concat(
		ROUND(
			SUM(have_replay_owner) / SUM(owner_send_nums),
			2
		),
		'%'
	)
) 回复率
FROM
	buried.online_housekeeper_stat_region
WHERE
	stat_time >= '2020-06-11'
AND stat_time <= '2020-06-14'
GROUP BY
	region
ORDER BY
	回复率 DESC;

SELECT
	*
FROM
	(
		SELECT
			region 地区,
			concat(
				floor(
					SUM(first_response_time_sum) / SUM(first_session_num) / 1000 / 3600
				),
				":",
				floor(
					SUM(first_response_time_sum) / SUM(first_session_num) / 1000 % 3600 / 60
				),
				":",
				floor(
					SUM(first_response_time_sum) / SUM(first_session_num) / 1000 % 3600 % 60
				)
			) 首次回复平均响应时长
		FROM
			buried.online_housekeeper_stat_region
		WHERE
			stat_time >= '2020-06-11'
		AND stat_time <= '2020-06-14'
		GROUP BY
			region
		HAVING
			SUM(first_session_num) > 0
		ORDER BY
			SUM(first_response_time_sum) / SUM(first_session_num) ASC
	) t
UNION
	SELECT
		region 地区,
		'0:0:0' 首次回复平均响应时长
	FROM
		buried.online_housekeeper_stat_region
	WHERE
		stat_time >= '2020-06-11'
	AND stat_time <= '2020-06-14'
	GROUP BY
		region
	HAVING
		SUM(first_session_num) = 0;

SELECT
	*
FROM
	(
		SELECT
			region 地区,
			concat(
				floor(
					SUM(response_time_sum) / SUM(session_num) / 1000 / 3600
				),
				":",
				floor(
					SUM(response_time_sum) / SUM(session_num) / 1000 % 3600 / 60
				),
				":",
				floor(
					SUM(response_time_sum) / SUM(session_num) / 1000 % 3600 % 60
				)
			) 回复平均响应时长
		FROM
			buried.online_housekeeper_stat_region
		WHERE
			stat_time >= '2020-06-11'
		AND stat_time <= '2020-06-14'
		GROUP BY
			region
		HAVING
			SUM(session_num) > 0
		ORDER BY
			SUM(response_time_sum) / SUM(session_num) ASC
	) t
UNION
	SELECT
		region 地区,
		'0:0:0' 回复平均响应时长
	FROM
		buried.online_housekeeper_stat_region
	WHERE
		stat_time >= '2020-06-11'
	AND stat_time <= '2020-06-14'
	GROUP BY
		region
	HAVING
		SUM(session_num) = 0;

SELECT
	ohsp.region 地区公司,
	ohsp.project 小区名称,
	sum(ohsp.message_quantity) 消息数量,
	sum(ohsp.owner_send_nums) 发送消息的用户个数,
	max(ohsp.total_house_number) 已售已收户数,
	IFNULL(max(aps.active_sum), 0) 活跃人数,

IF (
	IFNULL(max(aps.active_sum), 0) = 0,
	'0.0000%',
	concat(
		ROUND(
			sum(ohsp.owner_send_nums) / max(aps.active_sum) * 100,
			4
		),
		'%'
	)
) 使用率,

IF (
	SUM(ohsp.owner_send_nums) = 0,
	'0.00%',
	concat(
		ROUND(
			SUM(ohsp.have_replay_owner) / SUM(ohsp.owner_send_nums),
			2
		),
		'%'
	)
) 回复率,

IF (
	SUM(ohsp.first_session_num) = 0,
	'0:0:0',
	CONCAT(
		floor(
			SUM(
				ohsp.first_response_time_sum
			) / SUM(ohsp.first_session_num) / 1000 / 3600
		),
		":",
		floor(
			SUM(
				ohsp.first_response_time_sum
			) / SUM(ohsp.first_session_num) / 1000 % 3600 / 60
		),
		":",
		floor(
			SUM(
				ohsp.first_response_time_sum
			) / SUM(ohsp.first_session_num) / 1000 % 3600 % 60
		)
	)
) 首次回复的平均响应时长,

IF (
	SUM(ohsp.session_num) = 0,
	'0:0:0',
	CONCAT(
		floor(
			SUM(ohsp.response_time_sum) / SUM(ohsp.session_num) / 1000 / 3600
		),
		":",
		floor(
			SUM(ohsp.response_time_sum) / SUM(ohsp.session_num) / 1000 % 3600 / 60
		),
		":",
		floor(
			SUM(ohsp.response_time_sum) / SUM(ohsp.session_num) / 1000 % 3600 % 60
		)
	)
) 回复的平均响应时长
FROM
	buried.online_housekeeper_stat_project ohsp
LEFT JOIN buried.actives_project_statistics aps ON ohsp.community_id = aps.court_id
AND aps.initialDate = '2020-06-14'
AND aps. OFFSET = - 6
WHERE
	ohsp.stat_time >= '2020-06-11'
AND ohsp.stat_time <= '2020-06-14'
GROUP BY
	ohsp.project
UNION
	SELECT
		hcq.region_company 地区公司,
		hcq.project_name 小区名称,
		0 消息数量,
		0 发送消息的用户个数,
		IFNULL(hcq.total_house_number, 0) 已售已收户数,
		IFNULL(aps.active_sum, 0) 活跃人数,
		'0.0000%' 使用率,
		'0.00%' 回复率,
		'0:0:0' 首次回复的平均响应时长,
		'0:0:0' 回复的平均响应时长
	FROM
		dashboard_job.hdsc_cboard_query hcq
	LEFT JOIN buried.online_housekeeper_stat_project ohsp ON hcq.project_name = ohsp.project
	AND ohsp.stat_time >= '2020-06-11'
	AND ohsp.stat_time <= '2020-06-14'
	LEFT JOIN dashboard_job.exclude_project ep ON hcq.erp_precinct_short_name = ep.project_name
	LEFT JOIN buried.actives_project_statistics aps ON hcq.court_uuid = aps.court_id
	AND aps.initialDate = '2020-06-14'
	AND aps. OFFSET = - 6
	WHERE
		ep.project_name IS NULL
	AND ohsp.id IS NULL
	AND hcq.court_uuid IS NOT NULL;

SELECT
	region 地区公司,
	community_name 小区名称,
	session_id 会话的标识,
	stat_time 统计时间,
	send_time 会话发送时间,
	message 消息内容,
	user_name 发送消息人姓名,
	CASE user_type
WHEN 0 THEN
	'业主'
WHEN 1 THEN
	'管家'
END 人员类型,
 to_name 接收人姓名,
 CASE is_replay
WHEN 0 THEN
	'是'
WHEN 1 THEN
	'不是'
END 是否未回复,
 CASE is_first_no_replay
WHEN 0 THEN
	'不是'
WHEN 1 THEN
	'是'
END 是否首次未回复
FROM
	buried.chat_detail
WHERE
	stat_time >= '2020-06-11'
AND stat_time <= '2020-06-14';