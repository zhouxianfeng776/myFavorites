/**
 * @Probject Name: bm-sysusermgmt-service
 * @Path: com.eg.bm.sysusermgmt.web.voSysuserPageVo.java
 * @Create By 110655920
 * @Create In 2019年6月17日 上午8:47:17
 * TODO
 */
package com.hdkj.hwallet.oms.backend.sysuserMgt.pojo.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;


/**
 * 用户（分页）值对象
 *
 * @Class Name SysuserPageVO
 * @Author 110655920
 * @Create In 2019年6月17日
 */
@Data
@ApiModel
@AllArgsConstructor
public class IdmUserPageVO {

    @ApiModelProperty("记录总数")
    private int recordCount;

    @ApiModelProperty("用户列表")
    private List<IdmUserVO> userList;

}
