package com.hdkj.hwallet.oms.backend.sysuserMgt.pojo.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel
public class IdmUserQueryDTO extends PageBaseDTO {

    @ApiModelProperty("员工号")
    private String regName;

    @ApiModelProperty("姓名")
    private String realName;

}
