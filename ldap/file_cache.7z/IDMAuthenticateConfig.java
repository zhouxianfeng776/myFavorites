package com.hdkj.hwallet.oms.backend.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component
@ConfigurationProperties(prefix = "config.auth.idm")
public class IDMAuthenticateConfig {

    private String provider_url;

    private String principal;

    private String credentials;
}
