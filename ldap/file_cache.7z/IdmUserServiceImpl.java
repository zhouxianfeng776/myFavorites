package com.hdkj.hwallet.oms.backend.sysuserMgt.service.impl;

import com.hdkj.hwallet.oms.backend.sysuserMgt.pojo.dto.IdmUserQueryDTO;
import com.hdkj.hwallet.oms.backend.sysuserMgt.pojo.vo.IdmUserPageVO;
import com.hdkj.hwallet.oms.backend.sysuserMgt.pojo.vo.IdmUserVO;
import com.hdkj.hwallet.oms.backend.sysuserMgt.service.IIdmUserService;
import com.hdkj.hwallet.oms.backend.utils.LdapUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class IdmUserServiceImpl implements IIdmUserService {

    private static Logger logger = LoggerFactory.getLogger(IdmUserServiceImpl.class);

    @Autowired
    private LdapUtil ldapUtil;

    @Override
    public IdmUserPageVO queryIdmUsers(IdmUserQueryDTO queryDTO) {
        if (StringUtils.isBlank(queryDTO.getRegName()) && StringUtils.isBlank(queryDTO.getRealName())) {
            return new IdmUserPageVO(0, new ArrayList<>());
        }

        String basedn = "ou=People,dc=bizenit,dc=com";
        List<String> returnAttrs = new ArrayList<>();
        StringBuffer filter = new StringBuffer();
        assemblyFilterAndAttrs(queryDTO, returnAttrs, filter);
        List<Map> result = ldapUtil.getObjectsByFilter(basedn, filter.toString(), returnAttrs.toArray(new String[]{}));

        int size = result.size();
        int pageCount = size / queryDTO.getPageSize();
        int fromIndex = queryDTO.getPageSize() * (queryDTO.getPageNumber() - 1);
        int toIndex = fromIndex + queryDTO.getPageSize();
        if (toIndex >= size) {
            toIndex = size;
        }
        if (queryDTO.getPageNumber() > pageCount + 1) {
            fromIndex = 0;
            toIndex = 0;
        }

        List<IdmUserVO> users = new ArrayList<>();
        if (!CollectionUtils.isEmpty(result)) {
            try {
                users = result.subList(fromIndex, toIndex).stream().map(it -> {
                    IdmUserVO userVO = new IdmUserVO();
                    userVO.setPhone(org.springframework.util.StringUtils.isEmpty(it.get("mobile")) ? "" : String.valueOf(it.get("mobile")));
                    userVO.setRegName(String.valueOf(it.get("smart-alias")));
                    userVO.setRealName(String.valueOf(it.get("cn")));
                    userVO.setDeptName(String.valueOf(it.get("departmentname")));
                    return userVO;
                }).collect(Collectors.toList());
            } catch (Exception e) {
                logger.error("查询IDM账号异常： {}", e);
                throw e;
            }
        }

        return new IdmUserPageVO(size, users);
    }

    private void assemblyFilterAndAttrs(IdmUserQueryDTO queryDTO, List<String> returnAttrs, StringBuffer filter) {
        returnAttrs.add("departmentname");
        returnAttrs.add("mobile");
        returnAttrs.add("cn");
        returnAttrs.add("smart-alias");

        filter.append("(&(smart-type=E1)(smart-status=3)(smart-sources=0)(!(ds-pwp-account-disabled=true))");
        if (StringUtils.isNotBlank(queryDTO.getRealName())) {
            filter.append("(cn=*" + queryDTO.getRealName().trim() + "*)");
        }
        if (StringUtils.isNotBlank(queryDTO.getRegName())) {
            filter.append("(|(uid=" + queryDTO.getRegName().trim() + ")(smart-alias=" + queryDTO.getRegName().trim() + "))");
        }
        filter.append(")");
    }

    @Override
    public boolean login(String useruid, String userPassword) {
        return ldapUtil.getAuthenticator(useruid, userPassword);
    }

}