package com.hdkj.hwallet.oms.backend.utils;

import com.hdkj.hwallet.oms.backend.config.IDMAuthenticateConfig;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.*;
import java.util.*;

@Component
public class LdapUtil {

    public static final Logger log = LoggerFactory.getLogger(LdapUtil.class);

    @Autowired
    private IDMAuthenticateConfig idmAuthenticateConfig;

    /**
     * init ldap config
     *
     * @return
     */
    private DirContext initDirContext(String principal, String credentials) throws NamingException {
        Hashtable env = new Hashtable();
        env.put(Context.PROVIDER_URL, idmAuthenticateConfig.getProvider_url());
        env.put(Context.SECURITY_AUTHENTICATION, "simple");
        env.put(Context.SECURITY_PRINCIPAL, StringUtils.isBlank(principal) ? idmAuthenticateConfig.getPrincipal() : principal.trim());
        env.put(Context.SECURITY_CREDENTIALS, StringUtils.isBlank(credentials) ? idmAuthenticateConfig.getCredentials() : credentials.trim());
        env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
        env.put("com.sun.jndi.ldap.connect.pool", "true");
        return new InitialDirContext(env);
    }

    public boolean getAuthenticator(String useruid, String userPassword) {
        boolean result = false;

        // 认证成功后查询用户
        String searchFilter = "(|(uid=" + useruid + ")(smart-alias=" + useruid + "))";
        String[] returnAttrs = {"*"};
        NamingEnumeration<SearchResult> en = search("dc=bizenit,dc=com", searchFilter, returnAttrs);

        // 如果查询到用户账号在绑定账号中存在
        if (en != null && en.hasMoreElements()) {
            DirContext ctxUser = null;
            try {
                ctxUser = initDirContext(en.next().getNameInNamespace(), userPassword);
                result = true;// 用户认证成功
            } catch (NamingException e) {
                log.error("user Authentication occured NamingException,error message: " + e);
            } finally {
                processStreamClose(en, ctxUser);
            }
        }

        return result;
    }

    private void processStreamClose(NamingEnumeration<SearchResult> en, DirContext ctxUser) {
        if (ctxUser != null) {
            try {
                ctxUser.close();
            } catch (NamingException e1) {
                log.error("ctxUser close occured NamingException,error message:" + e1);
            }
        }
        if (en != null) {
            try {
                en.close();
            } catch (NamingException e) {
                log.error("close occured NamingException,error message:" + e);
            }
        }
    }

    private NamingEnumeration<SearchResult> search(String basedn, String filter, String[] attrs) {
        NamingEnumeration<SearchResult> en = null;
        log.info("LdapUtil search() query filter: " + filter);
        try {
            SearchControls constraints = new SearchControls();
            constraints.setSearchScope(SearchControls.SUBTREE_SCOPE);
            constraints.setReturningAttributes(attrs);
            DirContext ctx = initDirContext(null, null);
            en = ctx.search(basedn, filter, constraints);
        } catch (Exception e) {
            log.error("Exception in search(): " + e);
        }
        return en;
    }

    public List<Map> getObjectsByFilter(String basedn, String filter, String[] returnAttrs) {
        List<Map> result = new ArrayList<>();
        NamingEnumeration<SearchResult> ne = search(basedn, filter, returnAttrs);
        while (ne != null && ne.hasMoreElements()) {
            SearchResult sr = ne.nextElement();
            Attributes attrs = sr.getAttributes();

            Map<String, String> map = new HashMap();
            for (String returnAttr : returnAttrs) {
                //获取属性
                try {
                    getAttrValue(attrs, map, returnAttr);
                } catch (NamingException e) {
                    continue;
                }
            }
            result.add(map);
        }
        log.info("LdapUtil getObjectsByFilter() return data size: " + result.size());
        return result;
    }

    private void getAttrValue(Attributes attrs, Map<String, String> map, String returnAttr) throws NamingException {
        Attribute cnAttr = attrs.get(returnAttr);
        if (cnAttr != null) {
            Object cnobj = cnAttr.get();
            if (cnobj != null) {
                String cn = cnobj.toString();
                map.put(returnAttr, cn);
            }
        }
    }

}