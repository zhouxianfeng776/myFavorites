package com.hdkj.hwallet.oms.backend.sysuserMgt.service;

import com.hdkj.hwallet.oms.backend.sysuserMgt.pojo.dto.IdmUserQueryDTO;
import com.hdkj.hwallet.oms.backend.sysuserMgt.pojo.vo.IdmUserPageVO;

public interface IIdmUserService {

    IdmUserPageVO queryIdmUsers(IdmUserQueryDTO queryDTO);

    boolean login(String useruid, String userPassword);
}
