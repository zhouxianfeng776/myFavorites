package com.hdkj.hwallet.oms.backend.sysuserMgt.pojo.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel
public class IdmUserVO {

    @ApiModelProperty("手机号")
    private String phone;

    @ApiModelProperty("账号")
    private String regName;

    @ApiModelProperty("姓名")
    private String realName;

    @ApiModelProperty("部门名称")
    private String deptName;

}
